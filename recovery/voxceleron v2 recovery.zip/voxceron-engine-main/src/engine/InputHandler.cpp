#include "InputHandler.h"
#include <iostream>

InputHandler::InputHandler() {
    // Constructor
}

InputHandler::~InputHandler() {
    // Cleanup if necessary
}

void InputHandler::update() {
    processInput();
}

void InputHandler::processInput() {
    // Handle user input (keyboard, mouse, etc.)
}